package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.User;
import com.example.demo.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	
    @GetMapping("/userform")
    public String userForm(Model model) {
        model.addAttribute("user", new User());
        return "userform";
    }

    @PostMapping("/userform")
    public String userSubmit(@ModelAttribute User user) {
    	
    	this.userService.saveUser(user);
        return "result";
    }
}
