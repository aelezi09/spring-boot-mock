package com.example.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping(method = RequestMethod.GET, path="/student")
public class ArbiController {
	
	@GetMapping("/arbi")
	public String arbi(){
		return "arbi";
	}
	
}
